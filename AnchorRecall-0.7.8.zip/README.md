# Anchor Recall

Desktop-only Obsidian plugin for precise anchors and active recall across notes, PDFs, books, media, and documents.

**User guide (Russian):** [start here](docs/guide/index.md),
[first steps](docs/guide/getting-started.md), [settings](docs/guide/settings.md),
[import and backups](docs/guide/import-export-and-backups.md),
[troubleshooting](docs/guide/troubleshooting.md).

Development: [architecture and module map](ARCHITECTURE.md),
[contributing](CONTRIBUTING.md), [test strategy](tests/README.md).

The optional shared Telegram service is deployed separately from the plugin:
[Debian installation and standalone server build](docs/telegram-companion-debian.md).
It uses one operator-managed bot with per-user pairing. The bot token stays on
the service; desktop-to-service synchronization still requires a reachable
HTTPS endpoint and explicit selection of exported cards.

## License and commercial use

Anchor Recall's own code is licensed under the
[PolyForm Noncommercial License 1.0.0](LICENSE)
(`PolyForm-Noncommercial-1.0.0`). This is **source-available software**, not an
OSI-approved open-source license.

The license permits use, modification, and distribution for its permitted
purposes, including noncommercial purposes. It defines personal uses and
qualifying organizations explicitly; the restriction is broader than a ban on
selling forks or subscriptions. Do not assume that internal use at a commercial
company is permitted simply because the plugin itself is free.

For commercial use not covered by the license, contact **Gregory T.**, the
project maintainer, to request a separate written license before proceeding.
A request by itself does not grant permission. This summary does not replace
or amend the [official license terms](https://polyformproject.org/licenses/noncommercial/1.0.0).

When distributing covered code, retain the license text or its URL and the
`Required Notice` from `LICENSE`. Bundled third-party components keep their own
licenses; see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). The build embeds
the project license URL, required notice, and third-party notices in `main.js`
so they also accompany the standard three-file Obsidian installation.

This license change does not purport to revoke permissions already granted for
copies previously distributed under MIT. It does not impose a license on users'
notes, cards, source materials, or exported learning data.

## Features

- Imports and exports portable JSON libraries with card sources, sections, rules, topic hierarchies, tags and metadata sets. Structure and individual sets can also move without cards. A preview assigns new cards to the question bank or Core individually or in batches, remaps references, reuses unchanged records and blocks conflicting data before an atomic import. Fresh Core cards use FSRS; existing cards keep their roles and progress. Full backups remain the way to transfer learner progress. See [portable libraries and sets](docs/PORTABLE_LIBRARY.md).
- New Markdown anchors automatically prefill cards from case-insensitive `anchor-recall` blocks across the document; saving the material creates the chosen anchor and cards together. Explicitly removing the card draft keeps anchor-only creation. A separate review/import button remains above the document. Exact repeats in the same file are skipped; errors offer navigation and a return to the intact form. This is not automatic synchronization, and the note is never rewritten by discovery. See [Markdown import and keyboard hints](CARD_REVIEW.md#карточки-из-markdown-документа).
- Selects audio/video playback ranges in source anchors and card attachments; an explicit optional local FFmpeg/FFprobe export creates a separate WAV/MP4 clip without overwriting its source. See [media ranges and clip export](MEDIA_CLIPS.md).
- Stores invisible Markdown anchors in plugin data using selection, offset and surrounding-text fingerprints; new anchors never modify the note.
- Renders inline/fenced code and a bounded basic-math subset in tests and authoring previews. Exact-input references remain literal; no HTML, executable code, media embeds, links or user TeX macros. See [card content and comparison](CARD_REVIEW.md).
- Supports optional study boundaries in Markdown and ordinary PDF files: capture a selection or mark start/end separately, show a braided range rope and endpoint markers, and jump to either boundary. The creation/edit form has a source panel; choose PDF positions by clicking (including scanned pages), then return to the intact draft. Adding an end preserves the start; source changes apply on form save to the material's cards, never to source files. Markdown markers use the editor/Live Preview. See [study ranges](STUDY_RANGES.md).
- Creates PDF bookmarks from the native PDF.js location (`page`, `left`, `top`, `zoom`) without modifying the PDF file.
- Creates bookmarks for vault PDFs embedded in Markdown notes, preserving the host note, the exact embed instance, page and vertical position inside the page.
- Creates Canvas bookmarks using selected card IDs with the current viewport and zoom as a fallback when cards are removed.
- Keeps unsupported Canvas file cards navigable too: if a stable node ID changes, a unique vault file path is used before falling back to the saved board viewport. Inner position is only promised when the embedded viewer exposes it.
- Creates Excalidraw bookmarks using stable selected-element IDs, with the drawing viewport and zoom as a fallback when elements are removed.
- Creates compound bookmarks for PDF files placed on Canvas: Canvas file, stable card ID, PDF path, page and vertical position inside the page.
- Creates compound bookmarks for DOCX files placed on Canvas: stable card ID, DOCX path, page, text context and relative position inside the Word document.
- Creates PPTX bookmarks using the slide number, zoom, normalized point and rendered text, both in a regular tab and inside a stable Canvas card.
- Creates point bookmarks for image cards on Canvas using the stable card ID, image path and resolution-independent X/Y coordinates.
- Creates exact timestamp bookmarks for audio and video opened directly, embedded in Markdown, or placed on Canvas. A duration-relative fallback is stored without autoplaying media on navigation.
- Creates resilient bookmarks for TXT, JSON, HTML, FB2 and common source-code formats using line, column, absolute offset, selection and surrounding-text fingerprints, with Canvas card support and a relative-scroll fallback. FB2 binary cover payloads are ignored and rendered book text is normalized before matching.
- Creates EPUB, MOBI and AZW3 bookmarks using CFI, chapter/progress metadata and a text/scroll fallback. EPUB includes adapters for **ePub Reader** and **Awesome Reader**; **Weave EPUB Reader** provides a shared precise-position adapter for all three formats.
- Creates resolution-independent point bookmarks for PNG, JPG/JPEG, WebP, GIF, SVG, BMP and AVIF images.
- Creates DOCX bookmarks with the page, relative position, zoom, text fragment and a surrounding-text fallback. The primary viewer adapter is **Office Reader** (`word-reader`).
- Creates XLSX bookmarks through **Office Reader**, preserving the worksheet, active cell or selected rectangular range, and virtual-grid position. Navigation calls the reader's range navigator once after the workbook is ready.
- Creates compound XLSX bookmarks inside Canvas using the stable card ID, workbook path, worksheet and exact name-box range.
- Creates text-fragment bookmarks with a relative-scroll fallback for other document types supported by Obsidian.
- Restores the exact anchor; falls back to saved line, column and scroll height if the marker was deleted.
- Can briefly highlight the restored fragment, image point, or document area after navigation; this visual feedback does not affect anchor precision or modify source files.
- Coalesces simultaneous due reminders into one Obsidian and one Windows digest. The digest previews the five earliest cards, reports the remaining count, and offers direct session/list actions in Obsidian instead of flooding the desktop.
- Windows toasts use the Anchor Recall title and icon. Windows still identifies the sender process as Obsidian; a plugin cannot safely register an independent AppUserModelID without a separate installed companion application.
- Displays the originally scheduled time in the notification body; Windows supplies the actual delivery time.
- Shows every active overdue reminder again whenever Obsidian starts, even if it was already shown during an earlier session.
- Supports user-defined titles (80 character limit), up to 20 review intervals and optional repetition of the final interval.
- Includes a sidebar manager for editing, pausing, completing, snoozing, deleting and navigating to reminders.
- Automatically collapses cards from the same source material into compact groups inside each time section. Group headers show the material size, cards due today and new cards without changing scheduling or review priority; they also provide direct review, source, editing, and safely confirmed whole-group deletion actions. Search expands matching groups automatically.
- Supports anchor-first authoring: save a point or a Markdown/PDF range without cards, then add tests later from **Сохранённые якоря** in the manager. Anchors have no schedule and do not enter review queues. Adding more cards to a saved anchor reuses its material and preserves existing review histories; the anchor and its note remain saved.
- Searches the manager live by title, source path, question, or tag and supports keyboard-accessible multi-selection for bulk tagging, pause/resume, 24-hour deferral, and confirmed deletion.
- Keeps reminder paths valid when notes are renamed.
- Treats reminder shifts as review cycles: **Повторил** schedules the next cycle from the actual review time.
- Supports six active-recall formats: free response, single choice, multiple choice, cloze blanks, matching pairs, and ordering. Objective formats are checked automatically; free responses support manual self-checking or normalized exact-answer checking.
- Cloze templates can be a complete rectangular pipe table: the blank is an input inside its cell, and the table is retained when revealing or reviewing the answer. This reuses the existing cloze format, grading and import/export fields; see [table cloze](CARD_REVIEW.md#таблица-с-пропуском).
- Includes an **overview card** template for recalling a material's main ideas and structure without creating a separate whole-note mode. Any individual card can also keep up to three optional hints that are revealed one at a time during recall.
- Routes tested material through the recall screen before unlocking its source anchor; an explicit setting can expose a direct-source bypass.
- Lets the user choose a personal fixed scheme, **FSRS**, classic **SM-2**, or a simple six-level **Leitner** scheduler as the default for new tested material; each test preserves its selected algorithm and history.
- Can locally train personal FSRS parameters from accumulated review history through the official Rust/WASI optimizer. Training runs in a disposable worker, can be cancelled, and never blocks the Obsidian interface or sends history over the network.
- Presents one direct per-card planning choice: a fixed personal scheme, FSRS, SM-2, or Leitner. The personal scheme follows the user's intervals and can optionally include the same active-recall tests.
- Records **Again / Hard / Good / Easy** ratings and shows the calculated next review date before the source is opened.
- Builds a one-click smart daily review session from active tested material in the selected tag focus. Overdue cards remain first; within each due bucket, weak and attention-needed cards are shown before learning, stable, and strong cards. Smart interleaving separates repeated answers and similar prompts without moving later-today cards ahead of overdue work.
- Persists an unfinished review queue, its completed results and timer across Obsidian/plugin restarts. The sidebar Play icon and **Начать/Продолжить** button are the same action; a small options button changes the next run without adding a mandatory preflight screen.
- Limits each daily-session launch to a configurable workload and visible timer while keeping the number of launches unlimited. It supports removing a card only from the current run and can defer it for 24 hours without recording a false review.
- Offers linked study rounds when the timer expires: a 5/10/15-minute break, immediate continuation, or a final summary. Progress survives restart; breaks never count as study time. Optional queue refill preserves the original source filters and knowledge-group restrictions. See [session breaks](SESSION_BREAKS.md).
- Supports multiple independently scheduled recall cards for one source material and exact anchor; shared titles and tags stay synchronized while each card keeps its own question, algorithm state, due date, and review history.
- Creates a vault-scoped `obsidian://anchor-recall-review` link for any recall card, so a specific knowledge test can be opened directly without exposing its source text or answer in the URI.
- Links related source materials bidirectionally and offers the earliest active linked test immediately after grading, without forcing the original document to open between cards.
- Provides a dedicated learning-statistics view with today's workload, overdue cards, success rate, answer time, rating distribution, tag performance, and quick actions for automatically detected weak cards.
- Can move directly to the next card after a rating while keeping an in-session history of the question, submitted answer, reference answer, rating, and next due date for safe backward and forward review.
- Generates local test drafts from captured text without an API: cloze blanks, term-definition recall, Q/A blocks, checkbox choices, Markdown tables, ordered lists, and semantic self-recall. Every draft is previewed and must be explicitly accepted before it fills the editor.
- Warns about exact or similar batch questions and repeated correct answers before creation. Warnings remain advisory, so intentional reinforcement cards are never blocked.
- Batch Q/A, choice and cloze formats accept optional hints directly in the card data as `Подсказки: ["первая", "вторая", "третья"]`; the older repeated `Подсказка:` lines remain supported.
- Groups upcoming reviews into **Сейчас**, **Сегодня**, **На неделе**, and **Потом**.
- Includes a persistent tag library, saves newly entered tags immediately even if reminder creation is cancelled, supports up to eight tags per reminder, and remembers a one-click **focus direction** before dividing the selected material into time groups.
- Lets users safely remove library tags with confirmation and a 10-second undo, including restoring tag assignments to reminders.
- Shows the selected review scheme as a read-only cycle preview in the reminder editor, with current/passed states and expected dates for future stages.
- Keeps the complete review history inside each reminder card in a collapsible, scrollable panel.
- Stores materials/anchors, cards, permanent bookmarks, and immutable review events separately in normalized schema v1, with reference-integrity checks before every save or restore.
- Keeps the complete review journal instead of silently truncating older attempts.
- Creates rotating daily safety snapshots (10 latest), plus protected snapshots before a full restore or destructive bulk operation. Snapshot storage can stay beside the plugin, use a vault-relative folder, or point to any writable system folder selected by the user; existing snapshots are copied, never moved, when the location changes.
- Shows live data health in settings: normalized counts, revision, last save, latest snapshot and an on-demand integrity check next to immediate backup export.
- Exports settings, materials, cards, permanent bookmarks, scheduler state, and review history to a readable JSON backup; v1 copies are deeply validated before restoration.
- Supports named personal interval schemes with up to 20 review intervals; the final interval loops by default.
- Lets the user choose any personal interval scheme as the default for new reminders, or keep a separately configured default scheme.
- Accepts intervals in minutes, hours, days, weeks and fixed 30-day months, while storing them internally as minutes.
- Includes default, user-reassignable shortcuts: `Ctrl + Alt` on Windows/Linux or `Cmd + Option` on macOS; `+ R` creates a reminder, `+ B` saves a permanent anchored note, `+ M` opens the manager, `+ F` opens and focuses reminder search, and `+ S` starts the focused review session.
- Shows an optional in-session keyboard legend for Enter, ratings 2–4, hints, smart shuffle and history. The command palette also includes a responsive UI test bench for checking shared controls at 320, 560 and 860 px.

## Mark the source first, write cards later

1. Place the cursor or select a passage, then run **Создать материал** (`Ctrl + Alt + R`, or `Cmd + Option + R`). The existing `+ B` shortcut opens the same form with cards initially collapsed. Set the source, title, optional note, tags and topics, then use the single **Сохранить** button.
2. For a bounded Markdown/PDF passage, use **Создать материал из фрагмента**, or set **Начало / Конец** in that same form. Scanned PDFs support clicking a position on the page without selecting text.
3. **Добавить карточки** expands the optional single-test/batch editor. With an empty section and no manual reminder enabled, Save stores only the anchor. A started but incomplete test blocks saving; **Убрать карточки** requires confirmation before clearing entered questions, hints and answers. Hidden input in other formats is never silently discarded.
4. Closing a material, card, batch-card or rule editor keeps its unfinished form in the corresponding draft list. Card drafts include existing-card edits, incomplete raw answers, inactive formats and batch settings. If the draft cannot be written, the form stays open. Ordinary Save applies the changes and removes only that editor's draft; resuming never rewinds learning progress and refuses to overwrite changed card content or sources. **Удалить черновик** is a separate confirmed action in editors that expose it; the boundary-only editor still warns before discarding unconfirmed input.
5. **Напоминать без карточек** explicitly enables a regular manual reminder and reveals its date/intervals. Adding cards switches to test-based planning; existing reminders retain their schedules. No date or interval is required for a plain anchor.
6. Continue marking the file, then return through **Сохранённые якоря**. Editing the material or adding cards uses the same form and Save action. Source, metadata, note and optional cards are committed together; a failed save leaves the draft open.

Saved anchors remain separate from cards: removing an anchor does not delete its cards; removing cards does not remove the saved anchor. Source changes on explicitly linked anchors/cards apply to the shared material, without resetting existing schedules or history. See [source boundaries](STUDY_RANGES.md).

## Install for development

1. Enable Corepack, run `pnpm install --frozen-lockfile`, and then `pnpm build`.
2. Copy `manifest.json`, `main.js`, and `styles.css` into `<vault>/.obsidian/plugins/anchor-recall/`. The FSRS optimizer, its disposable worker, WASM module, and licensing notices are embedded in `main.js`, so a standard Community Plugins installation receives everything it needs. Do not strip the license banner from the bundle.
3. Enable **Anchor Recall** under Obsidian community plugins.

The technical plugin ID and installation folder are `anchor-recall`. Source identifiers use `AnchorRecall` in TypeScript and `anchor-recall` in CSS, links, and exported data.

### Upgrade from Remind Me Anchors

1. Disable the previous plugin and keep `<vault>/.obsidian/plugins/remind-me-anchors/data.json` as a safety copy.
2. Install this build into `<vault>/.obsidian/plugins/anchor-recall/` without deleting the previous folder yet.
3. Enable **Anchor Recall**. If the new installation has no data, it reads the previous `data.json`, validates schema v1, and writes a separate copy under the new plugin ID. The previous file is never modified or removed.
4. Check the data-health counts and open a few anchors before archiving the old folder. Reassign any custom command hotkeys if necessary because Obsidian scopes command preferences by plugin ID.

Previously generated `obsidian://remind-me-review` links, `remind-me-anchor:` Markdown markers, saved `remind-me-manager` workspace views, and `remind-me-topic-package` imports remain readable. Newly created data uses only Anchor Recall identifiers.

Use the command **Создать материал** while editing a Markdown note. **Создать материал с якорем** opens the same form with cards initially collapsed; a plain saved material needs no review schedule. For an embedded PDF, click or scroll inside that PDF first, leave it at the required position, and then run the command. Navigation opens the host note in reading mode and restores the embedded PDF page and position.

## Compatible viewers

Anchor Recall only promises an exact inner position for viewers that expose enough state to restore it. Installing several plugins for the same extension is not recommended because they can compete for the same Obsidian file view.

| Files | What to install | Anchor Recall support |
| --- | --- | --- |
| Markdown, PDF, Canvas, PNG/JPG/WebP/GIF/SVG/BMP/AVIF, audio and video | Nothing: use the built-in Obsidian views | Native editor/PDF.js/Canvas/media adapters. PDF embeds in Markdown are supported. |
| DOCX, PPTX, XLSX | [Office Reader](https://community.obsidian.md/plugins/word-reader) | Certified precise adapter for Word pages and text, PowerPoint slides, and Excel worksheets/ranges, including supported Canvas cards. Other Office viewers are not interchangeable with this adapter. |
| `.excalidraw`, `.excalidraw.md` | [Excalidraw](https://community.obsidian.md/plugins/obsidian-excalidraw-plugin) | Stable selected-element IDs, with drawing viewport and zoom as the fallback. |
| EPUB, MOBI, AZW3 | [Weave EPUB Reader](https://community.obsidian.md/plugins/weave-epub-reader) (recommended) | Precise CFI/progress adapter for all three book formats. MOBI/AZW3 require the reader's advanced support. |
| EPUB | [ePub Reader](https://community.obsidian.md/plugins/obsidian-epub-plugin) | Supported epub.js alternative using CFI, chapter and relative iframe position. |
| EPUB | [Awesome Reader](https://community.obsidian.md/plugins/awesome-reader) | Legacy adapter retained for existing libraries. The viewer has not been updated for years; choose Weave for a new setup. |
| TXT, JSON, HTML and source code | [Code Space](https://community.obsidian.md/plugins/code-space) or another in-Obsidian text editor | Exact line/selection when the viewer exposes an editor or CodeMirror lines; otherwise surrounding-text and relative-scroll fallback. This is interface-level compatibility rather than a viewer-specific certified adapter. |
| FB2 and TXT books | Weave EPUB Reader or another DOM text reader | Readable-text fingerprint and relative-scroll fallback. FB2 cover/image payloads are excluded from matching. |

The Anchor Recall settings page shows whether each known viewer is currently enabled, installed but disabled, or absent. **Office Reader** is the only supported Office implementation; similarly, a newly released EPUB or code viewer is not automatically certified merely because it opens the extension.

On Canvas, exact inner state is supported for native PDF cards, Office Reader DOCX/PPTX/XLSX cards, images, audio/video, and compatible text/code cards. Other file cards still keep the stable Canvas node and file path, but not an inner page. Inside Excalidraw, Anchor Recall can return to the selected Excalidraw element; it cannot currently inspect a page, timestamp, or scroll position inside a file embedded in that element.

For a Canvas bookmark, select one or more cards before running the command to create a stable card anchor. With no selection, the current Canvas viewport and zoom are saved instead. For a PDF card, click or scroll inside its PDF viewer and leave it on the required page before running the command. The plugin will first focus that Canvas card and then restore the page and the position inside it with one final scroll correction.

Any other Canvas file card, including book or Excalidraw previews whose embedded viewer does not expose an internal location API, still gets a resilient card-level bookmark. Anchor Recall first uses the Canvas node ID, then an unambiguous vault file path, and finally the saved board viewport. This fallback intentionally does not claim a page or scroll position that Obsidian never exposed.

Excalidraw bookmarks require the community plugin **Excalidraw**. Open the drawing in Excalidraw mode and select one or more elements before creating a reminder. Navigation finds those elements even after they have moved, selects them and fits them into view in one operation. With no selection, Anchor Recall restores the saved drawing viewport and zoom instead. Both `.excalidraw` and `.excalidraw.md` drawings use the same adapter.

EPUB, MOBI and AZW3 files require a compatible Obsidian book reader. Open the book and leave it at the required passage before creating a reminder. For **Weave EPUB Reader**, Anchor Recall flushes the reader's current position, stores its CFI and progress, and passes the CFI back during the initial book opening so navigation does not visibly run twice. Weave Reader requires its own premium access for MOBI/AZW3. EPUB readers based on `epub.js` continue to use their rendition CFI adapter; text and relative iframe position remain available as fallbacks.

For an image bookmark, click the exact point on the image before running the creation command. The point is stored as relative X/Y coordinates, so resizing the Obsidian window does not move the anchor. Navigation centers the saved point when scrolling is possible and briefly highlights it when visual anchors are enabled.

For an image placed on Canvas, click the exact point inside that image card before creating the bookmark. Navigation opens the host Canvas, finds and focuses the same card after it has been moved, and pulses the saved point. PNG, JPG/JPEG, WebP, GIF, SVG, BMP and AVIF use the same relative-coordinate anchor.

For audio or video, pause or seek to the required moment and then run the creation command. The bookmark stores the exact timestamp and the relative progress as a fallback. This works for a standalone media file, a Markdown embed, and a Canvas media card. Navigation pauses the player at the saved time and never starts playback automatically.

TXT, JSON, HTML, FB2 and source-code files require a compatible viewer that opens the file inside Obsidian. Put the cursor on the required line or select text before creating a bookmark. If the viewer exposes an Obsidian editor, navigation restores the exact line, column and selection in one operation. DOM-only readers use the text fingerprint and saved scroll ratio. For FB2, Anchor Recall extracts the readable XML text and excludes encoded cover/image payloads, so a rendered passage can be matched without depending on raw XML line breaks. The same fallback works for supported text/code/FB2 file cards on Canvas. Supported source formats include HTML/CSS, JavaScript/TypeScript, Python, Java/Kotlin, C/C++/C#, Go, Rust, Swift, PHP, Ruby, shell and PowerShell, SQL, XML, YAML, TOML and several other common text-based languages.

DOCX files require the community plugin **Office Reader**. Enable its detection of all file extensions, place the DOCX file inside the vault, open it, and wait until the pages appear. Scroll to the required passage or select its text before running the creation command. On navigation Anchor Recall waits for Office Reader to finish rendering and restoring its own state, then performs one final correction to the saved page and passage.

For a DOCX card on Canvas, click, scroll or select text inside the Word document before running the creation command. The bookmark first finds and focuses the same Canvas card, even after the card is moved, and then restores the saved DOCX page and passage inside that card.

PPTX files also use **Office Reader**. Open the required slide and optionally select its text before creating a bookmark. For a presentation placed on Canvas, interact with that particular slide card first. Navigation restores the slide through Office Reader's page control and then centers the saved point or matching text inside the rendered slide.

XLSX files use **Office Reader 3.0+**. Open the required worksheet and click a cell or drag a rectangular selection before creating a bookmark. The plugin stores zero-based sheet/cell coordinates and presents them as familiar references such as `B3:E9`. On navigation it waits for the virtualized grid to become ready, then switches to the saved worksheet and selects the range in one operation. The same workflow works for an XLSX file card on Canvas: interact with its grid first, and Anchor Recall will restore both the stable Canvas card and the workbook range.

For a quick notification check, run the command **Показать тестовое уведомление**. The alarm ribbon opens the reminder manager; use its **+** button or the creation command while a Markdown note is active.

The five frequent actions have default shortcuts shown in **Anchor Recall settings → Quick access**. They are regular Obsidian commands, so every binding can be removed or replaced under **Settings → Hotkeys** by searching for `Anchor Recall`. Destructive and test-only actions intentionally have no default global shortcut.

The optional card-source action **Переход без теста** is configured under **Anchor Recall settings → Карточки и занятия → Экран ответа и оценки**. It opens a card's saved source directly instead of first asking for an answer and rating. **Материалы → Открыть материал** always opens the material directly. Previously saved direct Obsidian test links remain readable for compatibility; deleted cards and materials without tests fail safely with an explanatory notice.

## Notes

Review schemes have an internal safety limit of 20 intervals. Embedded-PDF navigation relies on the DOM of Obsidian's native PDF viewer because Obsidian does not currently expose embedded viewer coordinates in its public plugin API. Google Calendar and the separately hosted shared Telegram companion are optional and require explicit connection. See the [integration settings guide](docs/guide/settings.md#интеграции).

## Data, privacy and desktop access

Card attachments and exported clips can also live in explicitly connected local media folders outside Obsidian. Choose **С компьютера** in the attachment editor or **На компьютере** when exporting a clip. Library IDs and relative paths travel with cards; absolute directory grants stay device-local and require reconnection elsewhere. See [EXTERNAL_MEDIA.md](EXTERNAL_MEDIA.md) for setup, limits and transfer instructions.

- Ordinary learning and local FSRS optimization keep learning data local. Google Calendar is optional and requires explicit connection. Enabled synchronization sends daily-window titles, review counts, completion status, dates/times, duration and reminder settings to the plugin's separate calendar. Individually selected tasks also send their titles, dates/times and completion status.
- Calendar events include a link back to Obsidian, which can reveal the vault name, and technical identifiers/hashes used to synchronize safely. Card questions, answers, review history, task notes and source-file contents are not included in Calendar payloads.
- Telegram is a different opt-in: selected material titles, eligible Core questions/references, exact-answer settings, complete choice/cloze definitions and technical review identifiers are sent to the shared service. Free responses, single/multiple choice and cloze use the same deterministic checks as Obsidian; memory ratings still control scheduling. Hints and attached images/audio/video require a separate opt-in. Questions keep their controls in one message and can be skipped without a grade. Ordinary users use the operator-provided HTTPS address and one-use pairing link, then confirm selected materials in Obsidian. One active vault per Telegram account is supported; Mini App also supports matching and ordering. Bank questions require a separate explicit opt-in and use independent practice history without changing Core schedules. Update the separately deployed server before the plugin. See [Telegram setup and limits](docs/telegram-companion.md) and [privacy and external integrations](docs/privacy.md).
- Primary data is stored by Obsidian in this plugin's `data.json`. By default, automatic safety snapshots are stored in the plugin's `data-snapshots` directory inside the vault configuration directory. Settings can redirect snapshots either to a validated vault-relative folder or to any writable absolute system path chosen explicitly by the user; missing folders are created automatically and existing snapshots are copied without deleting the originals.
- Manual JSON exports and topic templates are written to the operating system's **Downloads** directory. Outside the vault, Anchor Recall also writes explicit snapshots and clip exports to user-selected folders. External media access is limited by the plugin to explicitly connected local folders; disconnecting or deleting a card does not delete the files.
- The plugin is desktop-only because Windows notifications, downloads, and several document-reader adapters depend on Electron or desktop viewer plugins.
- DOCX, PPTX and XLSX navigation depends on **Office Reader**. EPUB/MOBI/AZW3 navigation depends on one of the compatible readers described above. Excalidraw navigation depends on the **Excalidraw** plugin.

## Current release scope

The local beta targets desktop Obsidian 1.13.7 or later. Automated and synthetic-host checks do not establish complete native acceptance; macOS and Linux certification remain pending. The shared Telegram implementation still requires final integrated verification, operator deployment and real Telegram/Obsidian acceptance; building the plugin does not activate a hosted service. Mobile is outside this release: Obsidian does not provide Node.js or Electron APIs there, while the current optimizer, downloads, system notifications, and several viewer adapters depend on those desktop capabilities. Existing data uses public storage schema v1; unsupported schemas are rejected without overwriting the source file.
# Knowledge retention statistics

The statistics dialog includes a collapsible **Сохранность знаний** section: current FSRS recall probability and forgetting risk by topic/tag, with explicit forecast coverage. Linked tests count as one knowledge unit; new and non-FSRS cards remain unknown. See [RETENTION_STATS.md](RETENTION_STATS.md) for calculation rules and limitations.
## Product direction and study materials

Card quality and source anchors are equal product pillars. Current work does not add AI generation or semantic grading. See [PRODUCT_DIRECTION.md](PRODUCT_DIRECTION.md) for staged improvements, [CARD_REVIEW.md](CARD_REVIEW.md) for literal answer matching and structured feedback, and [KNOWLEDGE_BASE_BRIEF.md](KNOWLEDGE_BASE_BRIEF.md) for the future English, logic, algorithms and architecture knowledge-base task.
